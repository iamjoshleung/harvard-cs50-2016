from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import gettempdir
from datetime import datetime

from helpers import *

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# custom filter
app.jinja_env.filters["usd"] = usd

# configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = gettempdir()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

@app.route("/")
@login_required
def index():
    users = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])
    
    # ensures the logged-in user exists
    if len(users) < 1:
        return apology("Error occurs")
        
    user = users[0]
    
    # get stocks the user owns
    stocks = db.execute("SELECT * FROM stock_holdings WHERE user_id = :user_id", user_id=user["id"])
    
    # grand total owned by the user
    grand_total = user["cash"]
    
    # if user holds no stock, render proper message
    if len(stocks) == 0:
        return render_template("index.html", stocks=stocks, cash=user["cash"], grand_total=grand_total)
    
    # for each stocks, lookup the current price
    # http://stackoverflow.com/questions/522563/accessing-the-index-in-python-for-loops
    for idx, stock in enumerate(stocks):
        result = lookup(stock["company_symbol"])
        if result:
            stocks[idx]["current_price"] = result["price"]
            stocks[idx]["name"] = result["name"]
            stocks[idx]["total"] = result["price"] * stocks[idx]["shares"]
            grand_total += stocks[idx]["total"]
        
        # else if unable to lookup stock
        else:
            stocks[idx]["current_price"] = "N/A"
            stocks[idx]["name"] = "N/A"
            stocks[idx]["total"] = "N/A"
    
    return render_template("index.html", stocks=stocks, cash=user["cash"], grand_total=grand_total)



@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock."""
    
    # if user reached route via GET
    if request.method == "GET":
        return render_template("buy.html")
        
    # if user reached route via POST
    else:
        
        symbol = request.form.get("symbol")
    
        # ensure symbol was submitted
        if not symbol:
            return apology("must provide symbol")
            
        symbol = symbol.lower()
            
        stock_info = lookup(symbol)
        
        # ensure symbol exists
        if not stock_info:
            return apology("symbol doesn't exist")
            
        shares = request.form.get("shares")
        
        # ensure shares was submitted
        if not shares or not is_int(shares):
            return apology("must provide shares")
            
        shares = int(shares)
            
        # ensure shares is a positive integer
        if shares <= 0:
            return apology("shares must be a positive integer")
            
        users = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])
            
        # ensures the logged-in user exists
        if len(users) < 1:
            return apology("Error occurs")
            
        user = users[0]
        
        # the amout of money to buy the shares
        desired_price = stock_info["price"] * shares
        
        # ensure user has enough money to buy the shares
        if user["cash"] < desired_price:
            return apology("you don't have enough money")
            
        # check if the user already holds shares from the company
        rows = db.execute("SELECT * FROM stock_holdings WHERE user_id = :user_id AND company_symbol = :company_symbol", 
                user_id=session["user_id"], company_symbol=symbol)
                
        # if user already holds shares, add more shares
        if len(rows) == 1:
            row = rows[0]
            new_shares = row["shares"] + shares
            db.execute("UPDATE stock_holdings SET shares = :new_shares WHERE user_id = :user_id AND company_symbol = :symbol", 
                new_shares=new_shares, user_id=session["user_id"], symbol=symbol)
        
        # else the user bought shares from the company for the first time , add a new row to the stock_holdings table
        else:
            db.execute("INSERT INTO stock_holdings (user_id, company_symbol, shares) VALUES (:user_id, :company_symbol, :shares)", 
                user_id=session["user_id"], company_symbol=symbol, shares=shares)
                
        # check if symbol exists in the companies table, if not, add new row
        rows = db.execute("SELECT * from companies WHERE symbol = :symbol", symbol=symbol)
        
        if len(rows) == 0:
            db.execute("INSERT INTO companies (symbol, name) VALUES (:symbol, :name)", symbol=symbol, name=stock_info["name"])
            
            
        # substract stock prices from user's cash
        new_cash = user["cash"] - desired_price
        db.execute("UPDATE users SET cash = :new_cash WHERE id = :user_id", new_cash=new_cash, user_id=session["user_id"])
        
        # log the transaction history
        db.execute("INSERT INTO transactions (user_id, company_symbol, type, price, shares) VALUES (:user_id, :company_symbol, :type, :price, :shares)",
            user_id=session["user_id"], company_symbol=symbol, type="buy", price=stock_info["price"], shares=shares)
            
        # http://stackoverflow.com/questions/415511/how-to-get-current-time-in-python
        # datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        result = {"symbol": symbol, "name": stock_info["name"], "price": stock_info["price"], 
            "amount": desired_price, "shares": shares, "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        return render_template("bought.html", result=result)
        


@app.route("/history")
@login_required
def history():
    """Show history of transactions."""
    
    # get all transactions performed by the user
    transactions = db.execute("SELECT * FROM transactions JOIN companies ON transactions.company_symbol = companies.symbol WHERE user_id = :user_id ORDER BY transactions.transacted_at DESC", user_id=session["user_id"])
    
    return render_template("history.html", result=transactions)
    

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # forget any user_id
    session.clear()

    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 1 or not pwd_context.verify(request.form.get("password"), rows[0]["hash"]):
            return apology("invalid username and/or password")

        # remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out."""

    # forget any user_id
    session.clear()

    # redirect user to login form
    return redirect(url_for("login"))

@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    
    # if user reached route via GET
    if request.method == "GET":
        
        return render_template("quote.html")
        
    # if user reached route via POST
    else:
        
        # ensure symbol was submitted
        if not request.form.get("symbol"):
            return apology("must provide symbol of the stock")
            
        # lookup the stock 
        result = lookup(request.form.get("symbol"))
        
        # ensure the result is successful
        if not result:
            return apology("can't find the stock you are looking for", "maybe type error?")
            
        return render_template("quoted.html", result=result)
        
        

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user."""
    
    # if user reached route via GET (as by clicking a link or via redirect)
    if request.method == "GET":
        
        return render_template("register.html")
    # else if user reached route via POST
    else:
        
        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")
        
        # ensure username is unique
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))
        
        if len(rows) > 0:
            return apology("username already exists")
            
        # ensure password was submitted
        if not request.form.get("password"):
            return apology("must provide password")
            
        # ensure passwords match
        if request.form.get("password") != request.form.get("password_confirmation"):
            return apology("passwords don't match")
            
        # hash the password
        hash = pwd_context.encrypt(request.form.get("password"))
            
        # add a new user to the users table
        db.execute("INSERT INTO users (username, hash) VALUES (:username, :hash)", username=request.form.get("username"), hash=hash)
    
        # redirect user to login page
        return redirect(url_for("login"))
        

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock."""
    
    # if user reached route via GET
    if request.method == "GET":
        return render_template("sell.html")
        
    # else if user reached route via POST
    else:
        symbol = request.form.get("symbol")
    
        # ensure symbol was submitted
        if not symbol:
            return apology("must provide symbol")
            
        symbol = symbol.lower()
            
        stock_info = lookup(symbol)
        
        # ensure symbol exists
        if not stock_info:
            return apology("symbol doesn't exist")
            
        shares = request.form.get("shares")
        
        # ensure shares was submitted
        if not shares or not is_int(shares):
            return apology("must provide shares")
            
        shares = int(shares)
            
        # ensure shares is a positive integer
        if shares <= 0:
            return apology("shares must be a positive integer")
            
        # ensure user has the stock
        stocks = db.execute("SELECT * FROM stock_holdings WHERE user_id = :user_id AND company_symbol = :symbol", 
            user_id=session["user_id"], symbol=symbol)
            
        if len(stocks) == 0:
            return apology("You don't own the stock")
            
        stock = stocks[0]
        
        # ensure user has enough shares to sell 
        if shares > stock["shares"]:
            return apology("You don't own enough shares you wanted to sell.")
            
        # subtract shares from stock_holdings
        new_shares = stock["shares"] - shares
        
        # if user sold all the shares of a stock, delete the entry
        if new_shares == 0:
            db.execute("DELETE FROM stock_holdings WHERE user_id = :user_id AND company_symbol = :symbol",
                user_id=session["user_id"], symbol=symbol)
        
        # else, update the entry
        else:
            db.execute("UPDATE stock_holdings SET shares = :new_shares WHERE user_id = :user_id AND company_symbol = :symbol",
                new_shares=new_shares, user_id=session["user_id"], symbol=symbol)
                
        # money gained from selling the shares
        money_gained = stock_info["price"] * shares;
        
        users = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])
            
        # ensures the logged-in user exists
        if len(users) < 1:
            return apology("Error occurs")
            
        user = users[0]
        
        # update cash the user owned
        new_cash = user["cash"] + money_gained
        
        db.execute("UPDATE users SET cash = :new_cash WHERE id = :id", new_cash=new_cash, id=session["user_id"])
        
        # log transaction
        db.execute("INSERT INTO transactions (user_id, company_symbol, type, price, shares) VALUES (:user_id, :company_symbol, :type, :price, :shares)",
            user_id=session["user_id"], company_symbol=symbol, type="sell", price=stock_info["price"], shares=shares)
            
        result = {"symbol": symbol, "name": stock_info["name"], "price": stock_info["price"], 
            "amount": money_gained, "shares": shares, "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
        return render_template("sold.html", result=result)
        
                
        
@app.route("/deposit", methods=["GET", "POST"])
@login_required
def deposit():
    # if user reached route via GET
    if request.method == "GET":
        return render_template("deposit.html")
        
    # else if user reached route via POST
    else:
        cash = request.form.get("cash")
        # ensure cash was submitted
        if not cash or not is_number(cash):
            return apology("cash must be provided")
            
        cash = float(cash)
            
        # ensure cash was positive and less than 1000
        if not (cash > 0 and cash <= 1000.0):
            return apology("cash must be positive and less than 1000")
            
        # add cash to user entry
        db.execute("UPDATE users SET cash = cash + :cash WHERE id = :id", cash=cash, id=session["user_id"])
        
        return render_template("deposited.html", cash=cash)
            
        
    