import sys
import cs50

def main():
    if len(sys.argv) != 2:
        print("Usage: python caesar.py k")
        exit(1)
        
    if int(sys.argv[1]) < 0:
        print("The command line argument must be a positive integer.")
        exit(1)
    
    # the caesar key
    k = int(sys.argv[1]) % 26;

    # ask user for plaintext 
    print("plaintext:")
    plaintext = cs50.get_string()
    
    # run caesar encryption
    encrypted = caesar(plaintext, k)
    
    print("{}".format(encrypted))
    
    exit(0)
    
# run the caesar encryption algorithm
# Variable: plaintext, str
# Variable: k, integer, caesar key
# Return: encrypted message
def caesar(plaintext, k):
    encrypted = ""
    
    for i in range( len(plaintext) ):
        # if the char is an alphebet, run caesar, else don't run
        if ((plaintext[i] >= 'a' and plaintext[i] <= 'z') or (plaintext[i] >= 'A' and plaintext[i] <= 'Z')):
            caesar_char = chr( ord(plaintext[i]) + k ) # the character after caesar encryption
            
        if (plaintext[i] >= 'a' and plaintext[i] <= 'z'):
            # determine if caesar_char overflows the range of allowed chars (a-z)
            # in such case we will wrap it around
            encrypted += chr( ord('a') + (ord(caesar_char) - ord('z')) - 1 ) if ord(caesar_char) > ord('z') else caesar_char;
        elif (plaintext[i] >= 'A' and plaintext[i] <= 'Z'):
            encrypted += chr( ord('A') + (ord(caesar_char) - ord('Z')) - 1 ) if ord(caesar_char) > ord('Z') else caesar_char;
        else:
            encrypted += plaintext[i]
            
    
    
    return encrypted

if __name__ == "__main__":
    main()