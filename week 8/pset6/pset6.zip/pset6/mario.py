import cs50

MIN_HEIGHT = 0    # minimum height of a pyramid
MAX_HEIGHT = 23   # maximum height of a pyramid

def main():
    
    i = get_positive_int()
    
    printHalfPyramid(i)
    
# Create a half-pyramid using hashes (#) for blocks
# Variable: i, int, height of pyramid
# Return: None
def printHalfPyramid(i):
    for n in range(i):
        printBlock(n+2, i)

# Print a line with i hashes (#) 
# Variable: i, int, the number of hashes in a line
#           height, the height of the pyramid
# Return: None
def printBlock(i, height):
    # print spaces preceding hashes
    num_spaces = height - i + 1
    for n in range( num_spaces ):
        print(" ", end="")
    
    # print hashes
    for n in range(i):
        print("#", end="")
    print()
    
# Get a positive integer
# Return: a positive integer
def get_positive_int():
    while True:
        print("Height: ", end="")
        n = cs50.get_int()
        if n >= MIN_HEIGHT and n <= MAX_HEIGHT:
            break
    return n
 
if __name__ == "__main__":
    main()