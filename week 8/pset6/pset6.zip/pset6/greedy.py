import cs50

QUATER = 25
DIME = 10
NICKLE = 5
PENNIE = 1

def main():
    print("O hai! ", end="")
    changes = get_positive_int("How much change is owed?")
    
    min_coins = runGreedy(changes)
    print("{}".format(min_coins))
    
# Run the greedy algorithm
# Variable: changes, int
# Return: a positive integer indicating the minimun coins with which said change can be made.
def runGreedy(changes):
    # convert cents to dollors
    changes_in_dollors = changes * 100
    
    # coins to return
    coins = 0
    
    while True:
        if changes_in_dollors >= QUATER:
            coins += 1
            changes_in_dollors -= QUATER
        elif changes_in_dollors >= DIME:
            coins += 1
            changes_in_dollors -= DIME
        elif changes_in_dollors >= NICKLE:
            coins += 1
            changes_in_dollors -= NICKLE
        elif changes_in_dollors >= PENNIE:
            coins += 1
            changes_in_dollors -= PENNIE
        else:
            break
    
    return coins
    

# Get a positive integer with a message
# Variable: msg, str, a message to print before asking for input
# Return: a positive integer
def get_positive_int(msg):
    while True:
        print("{}".format(msg))
        n = cs50.get_float()
        if n > 0.0:
            break
    return n
 
if __name__ == "__main__":
    main()