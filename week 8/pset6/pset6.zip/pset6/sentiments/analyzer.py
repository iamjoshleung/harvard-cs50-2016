import nltk

class Analyzer():
    """Implements sentiment analysis."""

    def __init__(self, positives="positive-words.txt", negatives="negative-words.txt"):
        """Initialize Analyzer."""
        self.positive_words = set()
        self.negative_words = set()
        
        # load words from positive-words.txt  
        file = open(positives, 'r')
        # for each line, if it doesn't start with ";" or empty line, add the word to the set
        for line in file:
            if not line in ['\n', '\r\n'] or not line[0] == ';':
                self.positive_words.add(line.rstrip('\n'))
        file.close()
        
        # load words from negative-words.txt
        file = open(negatives, 'r')
        # for each line, if it doesn't start with ";" or empty line, add the word to the set
        for line in file:
            if not line in ['\n', '\r\n'] or not line[0] == ';':
                self.negative_words.add(line.rstrip('\n'))
        file.close()
        


    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""

        # convert text to list by delimiter empty space
        words = nltk.word_tokenize(text.lower())
        
        # scores
        scores = 0
        
        #
        # for each word in words, check whether is a negative, 
        # positive or neutral word, and calculate the score as such
        #
        for word in words:
            if word in self.positive_words:
                scores += 1
            elif word in self.negative_words:
                scores -= 1
        
        return scores
        
