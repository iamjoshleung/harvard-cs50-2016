from flask import Flask, redirect, render_template, request, url_for

import helpers
from analyzer import Analyzer

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/search")
def search():

    # validate screen_name
    screen_name = request.args.get("screen_name")
    if not screen_name:
        return redirect(url_for("index"))

    # get screen_name's tweets
    tweets = helpers.get_user_timeline(screen_name, 100)
    
    if tweets == None:
        tweets = []
    
    # instantiate analyzer
    analyzer = Analyzer()

    # initialize scores
    positive_scores, negative_scores, neutral_scores = 0.0, 0.0, 0.0
    
    # calculate scores from tweets
    for tweet in tweets:
        score = analyzer.analyze(tweet)
        if score > 0.0:
            positive_scores += 1
        elif score < 0.0:
            negative_scores += 1
        else:
            neutral_scores += 1
    
    
    positive, negative, neutral = positive_scores, negative_scores, neutral_scores

    # generate chart
    chart = helpers.chart(positive, negative, neutral)

    # render results
    return render_template("search.html", chart=chart, screen_name=screen_name)
