/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

#define BLOCK 512
#define TITLE_SIZE 8
#define ELEMENT_READ_SIZE 1
#define JPG_SIGNATURE_SIZE 4

// return if the block of bytes contains JPG signature
bool isJPGSignature (unsigned char* block);

int main(int argc, char* argv[])
{
    // open card file
    FILE* intfile = fopen("card.raw", "r");
    
    if (intfile == NULL) 
    {
        printf("File couldn't be open.\n");
        return 2;
    }
    
    bool isJPG = false;
    int numFilesFound = 0;
    int numPadZeros = 2;
    FILE* JPGFile;
    
    // create a block of 512 bytes of memory
    unsigned char* jpgBlock = (unsigned char*) malloc(BLOCK);
    
    // while not the end of file
    while ( fread(jpgBlock, BLOCK, ELEMENT_READ_SIZE, intfile) == ELEMENT_READ_SIZE ) 
    {
        
        char title[TITLE_SIZE];
        
        // check if the first four bytes are JPG signature
        if ( isJPGSignature(jpgBlock) ) 
        {
            
            // if the previous jpg file is open, close it.
            if (isJPG) fclose(JPGFile);

            // create the title string
            if (numFilesFound >= 10) numPadZeros = 1;
            sprintf(title, "%.*s%d.jpg", numPadZeros, "00", numFilesFound);
            
            // open the new jpg file
            JPGFile = fopen(title, "w");
            
            // write the block to the file
            fwrite(jpgBlock, BLOCK, 1, JPGFile);
            
            numFilesFound++; 
            isJPG = true;
            
         
        }
        // 
        else if (isJPG)
        {
            // write the block to the file
            fwrite(jpgBlock, BLOCK, 1, JPGFile);
        }
        
    }
    
    
    
    
    // close file and free pointers
    fclose(JPGFile);
    fclose(intfile);
    free(jpgBlock);
    
    return 0;
    
    
}

bool isJPGSignature (unsigned char* block) 
{
    
    return block[0] == 0xff && block[1] == 0xd8 && block[2] == 0xff && (block[3] >= 0xe0 && block[3] <= 0xef);
}